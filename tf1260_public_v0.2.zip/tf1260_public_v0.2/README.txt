A lot of time and money has gone into making these so that you can enjoy. 

If you feel like making a donation please donate whatever you want to stephen@terriblefire.com

Just enjoy it. 

License is Creative Commons -- Attribution -- No Derivatives -- No Amigakit

------ 

Changelog

22/10/2021 - Added the correct assembly files.

21/10/2021 - Initial Release